import React, { useState } from "react";
import {
    View,
    TextInput,
    Text,
    StyleSheet,
    Alert,
    TouchableOpacity
} from 'react-native';
import { login } from "../services/api";

export default function LoginScreen({ navigation }) {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    const handleLogin = async () => {
        const result = await login(email, password);
        if (result.success) {
            navigation.navigate('Vagas', { user: result.user })
        } else {
            Alert.alert('Erro', result.message)
        }
    }

    return (
        <View style={styles.container}>
            <Text style={styles.title}> Login </Text>
            <TextInput style={styles.input} placeholder="E-mail" onChangeText={setEmail} />
            <TextInput style={styles.input} placeholder="Senha" onChangeText={setPassword} />
            <TouchableOpacity style={styles.button} onPress={handleLogin}>
                <Text style={styles.buttonText}>Entrar</Text>
            </TouchableOpacity>
            <Text style={styles.link} onPress={() => navigation.navigate('Cadastro')}> Criar Conta </Text>
        </View>
    )

}

const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        flex: 1,
        justifyContent: 'center',
        padding: 10,
        backgroundColor: '#feeeb8'
    },
    input: {
        borderWidth: 3,
        marginBottom: 10,
        marginLeft: 200,
        marginRight: 200,
        padding: 10,
        borderRadius: 15,
        color: 'white',
        borderColor: '#b695c0',
        backgroundColor: '#d5a6e4',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84
    },
    title: {
        fontSize: 34,
        fontWeight: 'semibold',
        marginBottom: 20,
        textAlign: 'center',
        color: '#b695c0',
    },
    button: {
        backgroundColor: '#b695c0',
        borderRadius: 15,
        paddingHorizontal: 30,
        paddingVertical: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        marginTop: 10,
    },
    buttonText: {
        color: 'white',
        fontSize: 18,
        textAlign: 'center',
        fontWeight: 'bold'
    },
    link: {
        marginTop: 20,
        color: '#d5a6e4',
        textAlign: 'center',
        fontSize: 20
    }
})