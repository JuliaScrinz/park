import React, { useState, useEffect } from "react";
import {
    View,
    TextInput,
    Button,
    Text,
    StyleSheet,
    Alert,
    FlatList,
    TouchableOpacity
} from 'react-native';
import { listarVagas, ocuparVaga, desocuparVaga } from "../services/api";

export default function VagasScreen({ route, navigation }) {
    const [vagas, setVagas] = useState([])
    //route chama o valor do usuário (variavel user) que veio junto com a rota
    const userId = route.params.user.id

    const fetchVagas = async () => {
        const result = await listarVagas()
        if (result.success) setVagas(result.vagas)
    }

    const handleOcupar = async (vagaId) => {
        const result = await ocuparVaga(vagaId, userId)
        Alert.alert(result.message)
        fetchVagas()
    }

    const handleDesocupar = async (vagaId) => {
        const result = await desocuparVaga(vagaId)
        Alert.alert(result.message)
        fetchVagas()
    }

    useEffect(() => { fetchVagas() }, [])

    const renderItem = ({ item }) => (
        <>
            <View style={styles.container}>
                <View style={styles.card}>
                    <Text style={styles.texto}> Vaga #{item.id} - {item.preferencial_int ? 'Preferencial' : 'Comum'} </Text>
                    <Text style={styles.texto}> Disponível: {item.disponivel ? 'Sim' : 'Não'} </Text>
                    {item.disponivel ? (
                        <TouchableOpacity style={styles.button} onPress={() => handleOcupar(item.id)}>
                            <Text style={styles.buttonText}>Ocupar</Text>
                        </TouchableOpacity>
                        // <Button title="Ocupar" onPress={() => handleOcupar(item.id)} />
                    ) : (
                        <TouchableOpacity style={styles.button} onPress={() => handleDesocupar(item.id)}>
                            <Text style={styles.buttonText}>Desocupar</Text>
                        </TouchableOpacity>
                        //<Button title="Desocupar" onPress={() => handleDesocupar(item.id)} />
                    )}
                </View>
            </View>
        </>

    )

    return (
        <>
            <View style={styles.screen}>
                <Text style={styles.link} onPress={() => navigation.navigate('Edit')}> Editar Usuário </Text>
                <FlatList
                    data={vagas}
                    keyExtractor={(item) => item.id.toString()}
                    renderItem={renderItem}
                    contentContainerStyle={{ padding: 20 }}
                />
            </View>
        </>
    )
}
const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        padding: 10,
        justifyContent: 'center',
    },
    card: {
        padding: 25,
        borderWidth: 1,
        borderRadius: 8,
        marginBottom: 10,
        backgroundColor: '#d5a6e4',
        borderColor: '#b695c0',
        padding: 10,
        marginLeft: 20,
        marginRight: 20,
        width: 700
    },
    texto: {
        color: 'white'
    },
    button: {
        backgroundColor: '#b695c0',
        borderRadius: 15,
        paddingHorizontal: 30,
        paddingVertical: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        marginTop: 10,
    },
    buttonText: {
        color: 'white',
        fontSize: 18,
        textAlign: 'center',
        fontWeight: 'bold'
    },
    link: {
        marginTop: 20,
        color: '#d5a6e4',
        textAlign: 'center',
        fontSize: 20,
        backgroundColor: '#feeeb8'
    },
    screen: {
        flex: 1,
        backgroundColor: '#feeeb8',
    },
    
    listContent: {
        padding: 20,
        paddingBottom: 40,
    },
    
})