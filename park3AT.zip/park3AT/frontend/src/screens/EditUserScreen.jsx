import React, { useState } from "react";
import {
    View,
    TextInput,
    Button,
    Text,
    StyleSheet,
    Alert,
    TouchableOpacity
} from 'react-native';
import { editarUsuario } from "../services/api";
 
export default function EditarUserScreen({ navigation, route }) {
    const userId = route.params?.id;
 
    const [form, setForm] = useState({
        username: '', email: '', placa: '',
        cor: '', modelo: ''
    });
 
    const handleChange = (name, value) => setForm({ ...form, [name]: value })
 
    const handleSubmit = async () => {
        const result = await editarUsuario(userId, form);
        console.log('Enviando dados:', form);
 
        if (result.success) {
            Alert.alert('Sucesso', result.message);
            navigation.navigate('Login');
        } else {
            Alert.alert('Erro', result.message || 'Erro ao editar usuário');
        }
    };
 
    return (
        <View style={styles.container}>
            <Text style={styles.title}>
                Editar Usuário
            </Text>
            {['username', 'email', 'placa', 'cor', 'modelo'].map((field) => (
                <TextInput 
                    key={field}
                    placeholder={field}
                    value={form[field]}
                    onChangeText={(value) => handleChange(field, value)}
                    style={styles.input}
                />
            ))}
            <TouchableOpacity style={styles.button} onPress={handleSubmit}>
                <Text style={styles.buttonText}>Editar</Text>
            </TouchableOpacity>
        </View>
    )
}
 
const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
    padding: 10,
    backgroundColor: '#feeeb8'
  },
  input: {
    borderWidth: 3,
    marginBottom: 10,
    marginLeft: 200,
    marginRight: 200,
    padding: 10,
    borderRadius: 15,
    color: 'white',
    borderColor: '#b695c0',
    backgroundColor: '#d5a6e4',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84
  },
  title: {
    fontSize: 34,
    fontWeight: 'semibold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#b695c0',
  },
  button: {
    backgroundColor: '#b695c0',
    borderRadius: 15,
    paddingHorizontal: 30,
    paddingVertical: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    marginTop: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    textAlign: 'center',
    fontWeight: 'bold'
  }
})
 