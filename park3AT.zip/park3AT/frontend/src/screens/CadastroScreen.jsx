import React, { useState } from "react";
import {
    View,
    TextInput,
    Button,
    Text,
    StyleSheet,
    Alert,
    TouchableOpacity
} from 'react-native';
import { cadastrar } from "../services/api";

export default function CadastroScreen({ navigation }) {
    const [form, setForm] = useState({
        username: '', password: '', email: '',
        placa: '', cor: '', modelo: ''
    })

    const handleChange = (name, value) => setForm({ ...form, [name]: value })

    const handleSubmit = async () => {
        const result = await cadastrar(form)
        console.log(form);
        
        if (result.success) {
            Alert.alert('Sucesso', result.message)
            navigation.navigate('Login')
        } else {
            Alert.alert('Erro', result.message)
        }
    }

    return (
        <View style={styles.container}>
            {['username', 'email', 'password', 'placa', 'cor', 'modelo'].map((field) => (
                <TextInput
                    key={field}
                    placeholder={field}
                    secureTextEntry={field === 'password'}
                    onChangeText={(value) => handleChange(field, value)}
                    style={styles.input}
                />
            ))}
            <TouchableOpacity style={styles.button} onPress={handleSubmit}>
                <Text style={styles.buttonText}>Cadastrar</Text>
            </TouchableOpacity>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        flex: 1,
        justifyContent: 'center',
        padding: 10,
        backgroundColor: '#feeeb8'
    },
    input: {
        borderWidth: 3,
        marginBottom: 10,
        marginLeft: 200,
        marginRight: 200,
        padding: 10,
        borderRadius: 15,
        color: 'white',
        borderColor: '#b695c0',
        backgroundColor: '#d5a6e4',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84
    },
    button: {
        backgroundColor: '#b695c0',
        borderRadius: 15,
        paddingHorizontal: 30,
        paddingVertical: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        marginTop: 10,
    },
    buttonText: {
        color: 'white',
        fontSize: 18,
        textAlign: 'center',
        fontWeight: 'bold'
    },
    link: {
        marginTop: 20,
        color: '#d5a6e4',
        textAlign: 'center',
        fontSize: 20
    }
})